- Requisitos
Python (Yo tengo 3.12.2)

Instalar paquetes en requirements.txt
pip install -r requirements.txt

pandas==2.1.3
scikit-learn==1.5.2
openpyxl
joblib
re
datetime

- Pasos para correr el código
1. Agregar archivo llamado "data.xlsx" en la misma ruta (puedo cambiar el nombre si me piden)
2. Correr el código llamado script_modelo_xgb2.py

Jugadores sin datos -3,-7,-21 no van a ser tenidos en cuenta para el calculo del índice
